<!DOCTYPE HTML>
<html>
<head>
<title>404 Error - Page Not Found</title>
<style>
            #ad_frame{ height:800px; width:100%; }
            body{ margin:0; border: 0; padding: 0; }
        </style>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="e7faa116fba98bee5b0a890a-text/javascript"></script>
<script type="e7faa116fba98bee5b0a890a-text/javascript" language="JavaScript">
            var url = 'http://www.searchvity.com/?dn='
                + document.domain + '&pid=9POL6F2H4';

            $(document).ready(function() {
                $('#ad_frame').attr('src', url);
            });
        </script>
</head>
<body>
<iframe id="ad_frame" src="https://www.searchvity.com/" frameborder="0" scrolling="no">

            <!-- browser does not support iframe's -->

        </iframe>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="e7faa116fba98bee5b0a890a-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js" data-cf-beacon='{"rayId":"56130212fecfd661","version":"2019.10.2","startTime":1581053806747}'></script>
</body>
</html>
